// The Platino API can be accessed via Alloy.Globals.Platino from any controller file. This makes it an automatic
// include. If you want to create other globals, the Alloy.Globals namespace is meant for just that.

Alloy.Globals.Platino = require('io.platino');
