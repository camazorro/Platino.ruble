// Redirect to the window controller for better naming conventions
var window = Alloy.createController('window').getView();
window.open();
